"""
A module that writes all the errors encountered to a file
called "error_log.txt"
"""
import datetime
import sys
import traceback

def log():
    
    f= open("error_log.txt","a")
    f.write("*"*80)
    f.write("\n"+str(datetime.datetime.now())+"\n")
    f.write(traceback.format_exc())
    f.close()   
    