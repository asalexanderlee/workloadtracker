<!DOCTYPE html>
<html lang="en">
  <head>
    <meta content="text/html; charset=windows-1252" http-equiv="content-type">
    <title>Search Faculty</title>
    
    <style>
	    * {
  				box-sizing: border-box;
			}
			body {
			  background: white;
			  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
			}
			
			#header {
			  color: black;
			  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
			  font-size: 40px;
			}
			
			#main {
				padding-bottom: 15px;
				padding-top: 15px;
				padding-left: 15px;
				padding-right: 15px;
				background-color: #ededed;
				border-radius: 5px;	
				text-align:center;
				margin:10%;
				margin-top:5%;
				height:600px;			
			}
			#retrieve_com_info_btn{
				background-color:#009999;
				color:white;
				padding:5px;
				margin:10px;
				font-size:13px;
				border:1px solid gray;
				border-radius:4px;	
				cursor:pointer;
			}
			#retrieve_com_info_btn:hover{
				background-color:#008080;	
			}
			#home_icon{
			  width:25px;
			  height:20px; 
			  color:white; 
			  position:relative;
			  cursor:pointer;
			}
		#home{
			position:fixed;
			background-color:#4d4dff;
			color:white;
			opacity:0.8;	
			padding:5px;
			top:0px;
			left:0px;
			border-radius:2px;
			cursor:pointer;
		}
		#home_text{
			position:relative;
			bottom:3px;
			margin-right:5px;
			cursor:pointer;	
		}
	</style>
  </head>
  <body>
	  <div id="home" onclick="document.getElementById('home_link').click();">
      		<img src="http://viaimmobiler.com/wp-content/uploads/2016/05/white-home-icon-house-icon-white-white-house-outline-hi.jpg" id="home_icon"/>
	     	<label id="home_text"><a id="home_link" style="color:white;text-decoration:none;" href="http://mcs3.davidson.edu/workloadtracker/home.html">Home</a></label>
	    </div>

	<div id="main">
        <form method="POST" action="committee_info.cgi">
        <h3>Retrieve information about committee</h3><br>
        <p>Select a committee in the first dropdown to display the information about the committee (size, members, points, etc.) or select a committee in the second dropdown to view the description of the committee (adapted from <em>The Davidson College Faculty Handbook</em>). If both dropdown selections are the same committee, both the committee information and description will be displayed.</p><br>
        <h4>Show committee structure and membership:
          <select id="committee_info" name="committee_info">
          <option value="default">Choose one</option>
          <?php
          
          foreach(array_keys($options) as $item){
            if (substr($item, -5) != "Chair") {
                
            ?>
            <option value="<?php echo $options[$item][0][0]; ?>">
            
            <?php echo $options[$item][0][0]; ?> </option>
            <?php
            }; }
              ?>
          </select>
          
          
        </h4>
        <h4>Show description of committee:
          <select id="description" name="description">
            <option value="default">Choose one</option>
          <?php
          foreach(array_keys($options) as $item){
            if (substr($item, -5) != "Chair") {
                
            ?>
            <option value="<?php echo $options[$item][0][0]; ?>">
            
            <?php echo $options[$item][0][0]; ?> </option>
            <?php
            }; }
              ?>

          </select>
        </h4>
        <input name="subchange" id="retrieve_com_info_btn" value="Retrieve Committee Information" type="submit">
        </form>
        </div> 
    
    </body>
</html>
