
<!DOCTYPE html>
<html>
	<head>
		<title>Find and Fill Vacancies</title>
		<style>
			*{
				font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
			}
			#main{
				background-color:#e6e6e6;
				padding:30px;	
              	min-height:600px;
              	margin:20px;
              	margin-bottom:100px;
              	min-width:1060px;
			}
			.acc{
				background-color:#cce6ff;
				border-radius:2px;
				box-shadow:2px 2px 10px gray;
				padding:0px;
				height:50px;	
				text-align:center;
				margin-left:10%;
				cursor:pointer;
				transition:0.5s;
				border:1px solid lightgray;
				overflow:hidden;
			}
          #main ul{
            	width:60%;
            	min-width:660px;
            	float:left;
            	margin-right:20px;
          }
			.content{	
				background-color:#e6f3ff;
				border-radius:2px;
				position:relative;
				transition:0.5s;
			}
			.down-arrow{
				width:20px;
				height:15px;	
			}
			.close-icon{
				width:20px;
				height:20px;
				margin:8px;
				float:right;
				cursor:pointer;	
			}
			.content_table{
				width:100%;	
				height:50px;
				border-bottom:2px solid lightgray;
			}
			.content_table td{
				padding:10px;
			}
			.prof_td{
				width:40%;	
			}
			.pos_td{
				width:10%;	
			}
			.yr_td{
				width:7%;
			}
			.replace_td{
				width:43%;
              text-align:left;
			}
			.replacement_input{
				padding:3px;	
			}
			li{
				display:block;	
			}
			.replace_button{
				background-color:#cccccc;
				border-radius:4px;
				border:1px solid gray;
				cursor:pointer;	
              display:inline-block;
			}
			.revert{
				background-color:#ffe6e6;
				border:1px solid lightgray;
				cursor:pointer;
				border-radius:4px;
              display:inline-block;
			}
			#submit_changes{
				background-color:#009999;
				color:white;
				padding:10px;
				margin:10px;
				margin-left:50%;
				font-size:16px;
				border:1px solid gray;
				transition:0.5s;
				border-radius:2px;	
			}
			#submit_changes:hover{
				box-shadow: 4px 4px 10px gray;
				cursor:pointer;	
			}
			#are_you_sure{
				display:none;
				background-color:#e6e6e6;
				border:1px solid #e6e6e6;
				border-radius:4px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 8px 20px 0 rgba(0, 0, 0, 0.19);
				padding:10px;
				position:fixed;
				top:25%;
				left:28%;
				width:40%;
				z-index:2;		
			}
			#blackout{
				position:fixed;
				display:none;
				z-index:1;
				width:100%;
				height:100%;
				margin:0px;
				top:0px;
				left:0px;
				background-color:black;
				opacity:0.5;	
			}
			.replace_lst{
				color:#009999;
				text-align:center;	
			}
			.bold_checkout{
				margin-left:10px;
				margin-right:10px;
				font-size:18px;	
			}
          #ok{
            background-color:#cccccc;
            border:1px solid #bfbfbf;
            border-radius:3px;
            cursor:pointer;
            padding:5px;
            font-size:15px;
            margin-left:42%;
          }
          #ok:hover{
            background-color:#99bbff;
          }
          #no{
            background-color:#668cff;
            border:1px solid #668cff;
            border-radius:3px;
            cursor:pointer;
            padding:10px;
            font-size:15px;
            float:left;
          }
          #ok:hover{
            background-color:#99bbff;
          }
          #yes{
            background-color:#cccccc;
            border:1px solid #bfbfbf;
            border-radius:3px;
            cursor:pointer;
            padding:10px;
            font-size:15px;
            float:right;
          }
          #yes:hover{
            background-color:#99bbff;
          }
          #open-collapse{
            background-color:#cccccc;
            width:5%;
            margin-top:0px;
            padding:5px;
            height:35px;
            text-align:center;
            box-shadow:2px 2px 2px gray;
            border-radius:10px;
            cursor:pointer;
          }
          #filter_div{
            float:right;
            background-color:white;
            width:30%;
            box-shadow: 5px 5px 10px gray;
            margin-top:15px;
            padding:10px;
            padding-top:5px;
            margin-bottom:20px;
            
          }
          .filter_container{
            background-color:lightgray;
            box-shadow: inset 2px 2px 8px gray;
            padding:5px;
            margin:20px;
          }
          .checkbox{
            margin:10px;
          }
          .replace_prof{
	       	font-size:15px;
	       	padding:0px;
	       	margin:0px;
	       	color:#7733ff;   
	      }
	      .replace_prof:hover{
		   	color:#4400cc;   
		  }
		  #home_icon{
			  width:25px;
			  height:20px; 
			  color:white; 
			  position:relative;
			  cursor:pointer;
			}
		#home{
			position:fixed;
			background-color:#4d4dff;
			color:white;
			opacity:0.8;	
			padding:5px;
			top:0px;
			left:0px;
			border-radius:2px;
			cursor:pointer;
		}
		#home_text{
			position:relative;
			bottom:3px;
			margin-right:5px;
			cursor:pointer;	
		}
		#your_changes{
			text-align:center;	
			font-size:18px;
		}
		#prof_left_bold{
			margin-left: 10px;
            margin-right: 10px;
            font-size: 18px;	
		}
		#prof_replace_bold{
			margin-left: 10px;
            font-size:18px;	
		}
		#do_you_wish_to_proceed{
			text-align:center;
            font-size:18px;
		}
          
		</style>
		<script>
			
			PROFS_LEAVING = [];
			PROFS_REPLACING = [];
          
  
 /*~~~~~~~~~~ Format Query to send to cgi ~~~~~~~~~~~~~~~~*/
         
          function formatQuery(){
	          var finalStr = "";
	          for (var i = 0; i < PROFS_LEAVING.length; i++){
		      	  finalStr += PROFS_LEAVING[i] + ":" + PROFS_REPLACING[i] + ",";
		      }
		     document.getElementById("replacements_query").value = finalStr; 
	      }
  /*~~~~~~~~~~ Collapse/ Uncollapse Button ~~~~~~~~~~~~~~~~*/
          
          function toggleCollapseBtn(){
            var btn = document.getElementById("open-collapse");
            if (btn.innerHTML == "Open All"){
              btn.innerHTML = "Collapse All";
              btn.style.backgroundColor = "#737373";
              btn.style.color = "white";
              btn.style.boxShadow = "2px 2px 2px black";
            }
            else{
              btn.innerHTML = "Open All";
              btn.style.backgroundColor = "#cccccc";
              btn.style.color = "black";
              btn.style.boxShadow = "2px 2px 2px gray";
            }
          }
          
  /*~~~~~~~~~~~~~~~~~ Collapse/ Uncollapse ~~~~~~~~~~~~~~~~*/
          
          function toggleCollapse(){
            toggleCollapseBtn();
            var accs = document.getElementsByClassName("acc");
            var btn = document.getElementById("open-collapse");
            for (var i = 0; i < accs.length; i++){
	            var curAcc = accs[i];
	        	if (btn.innerHTML == "Collapse All"){
					var curAccLen = (document.getElementsByClassName("(" + accs[i].id.substring(0,(accs[i].id.length - 4)) + ")_acc_content"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       )).length;
					var newHeight = String(50 + (curAccLen * 50)) + "px";
					curAcc.style.height = newHeight;
              	}
              	else{
	            	curAcc.style.height = "50px"; 	
	            }
            }
          }
          
          
 /*~~~~~~~~~~~~~~~~~~ Toggle Individual Accordion ~~~~~~~~~~~~~~~~*/
          
			function toggleAcc(ID){
				var curAcc = document.getElementById(ID);
				var curAccLen = (document.getElementsByClassName("(" + ID.substring(0,(ID.length - 4)) + ")_acc_content")).length;
				if (curAcc.style.height == "50px"){
					var newHeight = String(50 + (curAccLen * 50)) + "px";
					curAcc.style.height = newHeight;
				}
				else{
					curAcc.style.height = "50px";	
				}
			}
          
          
 /*~~~~~~~~~~~~~~~~~~~~ Remove from Array ~~~~~~~~~~~~~~~*/
          
			function removeFromArray(name, array){
				var index = array.indexOf(name);
				if (index != -1){
					array.splice(index, 1);	
				}
			}
          
          
 /*~~~~~~~~~~~~~~~~~~~~ Filter Replacement Profs ~~~~~~~~~~~~~~~*/
          
          function filterProfs(replaceChoicesID){
            document.getElementById(replaceChoicesID).style.display = "inline";
          }
          
          
 /*~~~~~~~~~~~~~~~~~~~~ Replace Name ~~~~~~~~~~~~~~~*/
          
			function changeName(inputID, oldNameID){
				var input = document.getElementById(inputID).value;
				if (input == ""){
					window.alert("Please enter a name.");	
				}
				else{
					var oldName = oldNameID;
					document.getElementById(oldNameID).innerHTML = "<b>" + input + "</b>";
					
					if ((document.getElementsByClassName('revert_' + oldName)).length == 0){
						var revertInput = document.createElement("INPUT");
						revertInput.type = "button";
						revertInput.className = "revert_" + oldName + " revert";
						revertInput.value = "Revert";
						revertInput.onclick = function(){
							document.getElementById(oldNameID).innerHTML = "<b>" + document.getElementById(oldNameID).className.substring(0,(document.getElementById(oldNameID).className.length - 8)) + "</b>";
							var parent = document.getElementById(inputID).parentElement;
							parent.removeChild(revertInput);
						
							removeFromArray(oldName, PROFS_LEAVING);
							removeFromArray(input, PROFS_REPLACING);
						}
					
						PROFS_LEAVING.push(oldName);
						PROFS_REPLACING.push(input);
					}
					else{
						var curIndex = PROFS_LEAVING.indexOf(oldName);	
						PROFS_REPLACING[curIndex] = input;
					}
					
					var appendTo = document.getElementById(inputID).parentElement;
					appendTo.appendChild(revertInput);
					document.getElementById(inputID).value = "";
				}	
			}
          
          
/*~~~~~~~~~~~~~~~~~~~~ Remove HTML element ~~~~~~~~~~~~~~~*/
          
          function removeElement(element){
            var parent = element.parentElement;
            parent.removeChild(element);
          }

          
/*~~~~~~~~~~~~~~~~~~~~ Close Submit Message ~~~~~~~~~~~~~~~*/
          
          function closeMsg(curDiv){
            curDiv.style.display = "none";
		    document.getElementById("blackout").style.display = "none";
          }
          
          
/*~~~~~~~~~~~~~~~~~~~~ Delete Generated Message After Closing ~~~~~~~~~~~~~~~*/          
          
          function deleteMsg(){
            removeElement(document.getElementById("your_changes"));
            removeElement(document.getElementById("do_you_wish_to_proceed"));
            var replaceLst = document.getElementsByClassName("replace_lst");
            for (var i = 0; i < replaceLst.length; i++){
              removeElement(replaceLst[i]);
            }
            removeElement(document.getElementById("no"));
            removeElement(document.getElementById("yes"));
            
            document.getElementById("are_you_sure").style.display = "none";
            document.getElementById("blackout").style.display = "none";
          }
          
          
 /*~~~~~~~~~~~~~~~~~~~~ Delete Generated No Changes Message After Closing ~~~~~~~~~~~~~~~*/
          
          function deleteNoChangeMsg(){
            removeElement(document.getElementById("ok"));
            removeElement(document.getElementById("no_changes"));
            
            document.getElementById("are_you_sure").style.display = "none";
            document.getElementById("blackout").style.display = "none";
          }
          
 
 /*~~~~~~~~~~~~~~~~~~~~ Create an html element with all of your specifications, 
 including id, value,className, etc~~~~~~~~~~~~~~~*/
          
          function createSpecialElement(elementType, ID, textNode, className, value){

	          var element = document.createElement(elementType);
	          
	          if (ID != ""){
		      	element.id = ID;
		      }   	
		      if (textNode != ""){
			    element.appendChild(document.createTextNode(textNode));
			  } 
			  if (className != ""){
				  element.className = className;
			  }  
			  if (value != ""){
				  element.value = value;
			  } 
			  
			  return element;
	      }
	      
	      
	      
 /*~~~~~~~~~~~~~~~~~~~~ Create Message with Summary of all Changes ~~~~~~~~~~~~~~~*/
          
          function createChangesMsg(curDiv){
	          
	          /*Creates the header of the message*/
	          var yourChanges = createSpecialElement("P","your_changes","Your Changes: ","","");
              curDiv.appendChild(yourChanges);
                 
              /*Creates the div that holds all of the changes the user has made*/
              var changesDiv = document.createElement("DIV");
              
              /*Creates text nodes containing all of the changes made and appends them to the div*/
              for (var i = 0; i < PROFS_LEAVING.length; i++){
                  var curP = createSpecialElement("P","","You replaced ","replace_lst","");

                  var profLeftBold = createSpecialElement("B","prof_left_bold",PROFS_LEAVING[i],"","");
                  curP.appendChild(profLeftBold);

                  curP.appendChild(document.createTextNode(" with "));

                  var profReplaceBold = document.createElement("B");
                  profReplaceBold.id = "prof_replace_bold";
                  profReplaceBold.appendChild(document.createTextNode(PROFS_REPLACING[i]));
                  curP.appendChild(profReplaceBold);

                  curP.appendChild(document.createTextNode("."));

                  changesDiv.appendChild(curP);
               }
               
               /*Only turn the div into a scroll if the list gets big enough*/
               if (i > 7){
	            	changesDiv.style.overflowY = "scroll"; 
	            	changesDiv.style.height = "250px";   
	           }
	           
	           curDiv.appendChild(changesDiv);
	           
	           /*Do you still wish to proceed? paragraph*/
               var p = document.createElement("P");
               p.id = "do_you_wish_to_proceed";
               p.appendChild(document.createTextNode("Do you still wish to proceed?"));
               curDiv.appendChild(p);
				
				/*Create no button*/
               var no = document.createElement("INPUT");
               no.type = "button";
               no.value = "No";
               no.id = "no";
               
               /*Create yes button*/
               var yes = document.createElement("INPUT");
               yes.type = "button";
               yes.value = "Yes";
               yes.id = "yes";
               
              no.onclick = function(){
	              /*remove all of the elements that were just 
	              generated to avoid seeing it when you generate a new message*/
                removeElement(p);
                removeElement(curP);
                removeElement(yourChanges);
                removeElement(no);
                removeElement(yes);
                removeElement(changesDiv);
                closeMsg(curDiv);
              }
              curDiv.appendChild(no);
              
              yes.onclick = function(){
	              /*remove all of the elements that were just 
	              generated to avoid seeing it when you generate a new message*/
                removeElement(p);
                removeElement(curP);
                removeElement(yourChanges);
                removeElement(no);
                removeElement(yes);
                removeElement(changesDiv);
                closeMsg(curDiv);
                
                formatQuery(); /*take all of the changes and submit them to cgi file*/
              }
              curDiv.appendChild(yes);
              
              document.getElementById("close_msg").onclick = function(){
                  deleteMsg();
                }
            }
          
          
 /*~~~~~~~~~~~~~~~~~~~~ Submit function ~~~~~~~~~~~~~~~*/
          
			function checkout(){
				var curDiv = document.getElementById('are_you_sure');
				curDiv.style.display = "block";
				document.getElementById("blackout").style.display = "block";
				
                if (PROFS_LEAVING.length != 0){
                  /*<p style="text-align:center;font-size:18px;">Your Changes:</p>*/  
                  createChangesMsg(curDiv);
                }
              else{
                var p = document.createElement("P");
                p.style.textAlign = "center";
                p.style.fontSize = "18px";
                p.id = "no_changes";
                p.appendChild(document.createTextNode("You have made no changes."));
                curDiv.appendChild(p);
                
                var ok = document.createElement("INPUT");
                ok.type = "button";
                ok.id = "ok";
                ok.value = "OK";
                ok.onclick = function(){
				  curDiv.style.display = "none";
				  document.getElementById("blackout").style.display = "none";
                  var parent = ok.parentElement;
                  parent.removeChild(ok);
                  parent = p.parentElement;
                  parent.removeChild(p);
                }
                
                curDiv.appendChild(ok);
                
                document.getElementById("close_msg").onclick = function(){
                  deleteNoChangeMsg();
                }
              }
				
			}
          
          
 /*~~~~~~~~~~~~~~~~~~~~ Toggle Checkbox ~~~~~~~~~~~~~~~*/
          
          function toggleCheckbox(ID){
            var curElem = document.getElementById(ID);
            var curElemInput = document.getElementById(curElem.htmlFor);
            if (curElemInput.checked){
              curElem.style.color = "#258e8e";
            }
            else{
              curElem.style.color = "black";
            }
          }
          
          
/*~~~~~~~~~~~~~~~~~~~~ Checks if the HTML has a class ~~~~~~~~~~~~~~~*/
          
          function hasClass(target, classname) {
             var lst = target.classList;    
            return lst.contains(classname);
          }
          
          
 /*~~~~~~~~~~~~~~~~~~~~ Restore all of the Divs after unchecking a filter input ~~~~~~~~~~~~~~~*/
          
          function restore(){
            var allAccs = document.getElementsByClassName("acc");
            for (var i = 0; i < allAccs.length; i++){
              allAccs[i].style.display = "block";
            }
            
            var allInputs = document.getElementsByClassName("checkbox");
            for (var j = 0; j < allInputs.length; j++){
              if (allInputs[j].checked){
                filter(allInputs[j].id, (allInputs[j].id + "_text"));
              }
            }
          }
          
          
/*~~~~~~~~~~~~~~~~~~~~ Filter ~~~~~~~~~~~~~~~*/
          
          function filter(classname, label){
            toggleCheckbox(label);
            var allAccs = document.getElementsByClassName("acc");
            
            var curInput = document.getElementById(document.getElementById(label).htmlFor);

            if (curInput.checked){
              for (var i = 0; i < allAccs.length; i++){
                if (!hasClass(allAccs[i], classname)){
                  allAccs[i].style.display = "none";
                }
              }
            }
            else{
               restore();
            }
          }



/*~~~~~~~~~~~~~~~~~~~~~~~ Filter Profs in replacement input textbox ~~~~~~~~~~~~~~~~~~~~~~~*/

		var possProfReplacements = ['Alexander-Lee, Ashley', 'Mulat, Hermon'];
          function filterProfs(ID){

			var curInput = document.getElementById(ID).value.toLowerCase();
			var inputLen = curInput.length;
	
			var i;
			for (i = 0; i < possProfReplacements.length; i++){
				var curElem = possProfReplacements[i];
				var curSubStr = curElem.value.substring(0,inputLen).toLowerCase();
		
				if (curSubStr !== curInput){
					curElem.parentElement.style.display = "none";	
				}	
				else{
					curElem.parentElement.style.display = "block";	
				}
			}
		}
		
		</script>
	</head>
	<body>
      
      
      <!--~~~~~~~~~~~~~~~~~ Blackout ~~~~~~~~~~~~~~~~~~~~~-->
      
		<div id="blackout">
		</div>
      
      
      <!--~~~~~~~~~~~~~~~~~ Header ~~~~~~~~~~~~~~~~~~~~~~~-->
      
		<h1 style="font-size:40px;text-align:center;">Find and Fill Upcoming Vacancies</h1>
		<div id="home" onclick="document.getElementById('home_link').click();">
      		<img src="http://viaimmobiler.com/wp-content/uploads/2016/05/white-home-icon-house-icon-white-white-house-outline-hi.jpg" id="home_icon"/>
	     	<label id="home_text"><a id="home_link" style="color:white;text-decoration:none;" href="http://mcs3.davidson.edu/workloadtracker/home.html">Home</a></label>
	    </div>
      
      <!--~~~~~~~~~~~~~~~~~ Main ~~~~~~~~~~~~~~~~~~~~~~~~-->
      
		<div id="main">
          <p id="open-collapse" onclick="toggleCollapse();">Open All</p>
          
			<!-- Generate for each committee -->
			<ul style="height:500px; overflow-y:scroll;">
				{% for i in data %}
				<li>
					<script>classname = "acc ";</script>
					
			<div id="{{i}}_acc" style="height:50px;" class="">
				<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Grey_close_x.svg/1024px-Grey_close_x.svg.png" class="close-icon" onclick="document.getElementById('{{i}}_acc').style.display = 'none';">
				<p onclick="toggleAcc('{{i}}_acc')">{{i}}</p>
				<div class="content">
					{% for j in data[i] %}
					<table class="({{i}})_acc_content content_table">
						<tr>
							<td class="{{j[2]}} prof_td" id="{{j[0]}}"><b>{{j[2]}}</b></td>
							<td class="pos_td">{{j[3]}}</td>
							<td class="yr_td">{{j[4]}}</td>
							<td class="replace_td" id="{{j[0]}}_replace"></td>
							<script>
								if (classname.indexOf("{{j[3]}}") == -1){
									classname += "{{j[3]}} ";
								} 
								if (classname.indexOf("{{j[1]}}") == -1){
									classname += "{{j[1]}}_pt ";
								} 
								if ((classname.indexOf("vacancy") == -1) && ("{{j[4]}}" == "16")){
									classname += "vacancy ";
								}  
							</script>
							<script>
								if ({{j[4]}} == "16"){
									var replace_td = document.getElementById("{{j[0]}}_replace");
									var replace_div = document.createElement("DIV");	
									replace_div.id = "replace_div_{{j[0]}}";
									var replace_input = document.createElement("INPUT");
									replace_input.type = "text";
									replace_input.className = "replacement_input";
									replace_input.list = "prof_replacements_{{j[0]}}";
									replace_input.id = "replace_{{j[0]}}";
									replace_input.placeholder = "Replacement Member";
									
									replace_div.appendChild(replace_input);
									
									var datalist = document.createElement("DATALIST");
									datalist.id = "prof_replacements_{{j[0]}}";
									var option = document.createElement("OPTION");
									option.value = "Alexander-Lee, Ashley";
									datalist.appendChild(option);
									replace_div.appendChild(datalist);

									var inputBtn = document.createElement("INPUT");
									inputBtn.type = "button";
									inputBtn.className = "replace_button";
									inputBtn.value = "Enter";
									inputBtn.onclick = function(){
										changeName("replace_{{j[0]}}","{{j[0]}}"); 
									};
									replace_div.appendChild(inputBtn);
									replace_td.appendChild(replace_div);
								}	
								else{
									var replace_td = document.getElementById("{{j[0]}}_replace");
									
									var replace_prof_manual = document.createElement("P");
									replace_prof_manual.className = "replace_prof";
									replace_prof_manual.id = "replace_prof_{{j[0]}}";
									replace_prof_manual.appendChild(document.createTextNode("Replace Member"));
									var replace_div = document.createElement("DIV");	
									replace_div.id = "replace_div_{{j[0]}}";
									replace_div.style.display = "none";
									
									var replace_input = document.createElement("INPUT");
									replace_input.type = "text";
									replace_input.className = "replacement_input";
									replace_input.list = "prof_replacements_{{j[0]}}";
									replace_input.id = "replace_{{j[0]}}";
									replace_input.placeholder = "Replacement Member";
									
									replace_div.appendChild(replace_input);
									
									/*var datalist = document.createElement("DATALIST");
									datalist.id = "prof_replacements_{{j[0]}}";
									replace_div.appendChild(datalist);*/
									
									var inputBtn = document.createElement("INPUT");
									inputBtn.type = "button";
									inputBtn.className = "replace_button";
									inputBtn.value = "Enter";
									inputBtn.onclick = function(){
										changeName("replace_{{j[0]}}","{{j[0]}}"); 
									};
									replace_div.appendChild(inputBtn);
									
									replace_prof_manual.onclick = function(){
										document.getElementById("replace_div_{{j[0]}}").style.display = "block";
										document.getElementById("replace_prof_{{j[0]}}").style.display = "none";
									}
									
									replace_td.appendChild(replace_prof_manual);
									replace_td.appendChild(replace_div);		
								}
							</script>
							
						</tr>
					</table>
					{% endfor %}
					
					<script>document.getElementById("{{i}}_acc").className = classname;</script>
				<div>
			</div>
			</li>
			{% endfor %}			
			</ul>
			
              
            <!--~~~~~~~~~~~~~~ Filter Profs ~~~~~~~~~~~~-->
              
            <div id="filter_div">
              <p style="text-align:center;border-bottom:1px solid black;">Filter By</p>
              
              <!--~~~~~~~~~~~ Only Vacancies ~~~~~~~~~~~~-->
              <input type="checkbox" class="checkbox" id="vacancy" onclick="filter('vacancy', 'vacancy_text');"/><label for="vacancy" id="vacancy_text">Only committees with vacancies</label>
              
              <!--~~~~~~~~~~~~~~~ Position ~~~~~~~~~~~~~~~-->
              <p style="color:gray;margin-left:20px;">Position:</p>
              <div class="filter_container">
                <input type="checkbox" class="checkbox" id="AL" onclick="filter('AL', 'AL_text');"/><label for="AL" id="AL_text">At Large (AL)</label><br>
                <input type="checkbox" class="checkbox" id="PRES" onclick="filter('PRES','PRES_text');"/><label for="PRES" id="PRES_text">Presidential Appointment (PRES)</label><br>
                <input type="checkbox" class="checkbox" id="SS" onclick="filter('SS','SS_text');"/><label for="SS" id="SS_text">Social Sciences (SS)</label><br>
                <input type="checkbox" class="checkbox" id="NSM" onclick="filter('NSM','NSM_text');"/><label for="NSM" id="NSM_text">Natural Science and Math (NSM)</label><br>
                <input type="checkbox" class="checkbox" id="HUM" onclick="filter('HUM','HUM_text');"/><label for="HUM" id="HUM_text">Humanities (HUM)</label><br>
              </div>
              
              <!--~~~~~~~~~~~~~~~~~ Points ~~~~~~~~~~~~~~~-->
              <p style="color:gray;margin-left:20px;">Points:</p>
              <div class="filter_container">
                <input type="checkbox" class="checkbox" id="0_pt" onclick="filter('0_pt','0_pt_text');"/><label for="0_pt" id="0_pt_text">0</label>
                <input type="checkbox" class="checkbox" id="1_pt" onclick="filter('1_pt','1_pt_text');"/><label for="1_pt" id="1_pt_text">1</label>
                <input type="checkbox" class="checkbox" id="2_pt" onclick="filter('2_pt','2_pt_text');"/><label for="2_pt" id="2_pt_text">2</label>
                <input type="checkbox" class="checkbox" id="3_pt" onclick="filter('3_pt','3_pt_text');"/><label for="3_pt" id="3_pt_text">3+</label>
              </div>
            </div>
             
             
             <input type="text" name="replacements_query" id="replacements_query" value="" hidden/> 
            <!--~~~~~~~~~~~~~~~ Submit ~~~~~~~~~~~~~~~~-->
			<input type="button" value="Submit Changes" id="submit_changes" onclick="checkout()"/>
			<div id="are_you_sure">
				<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Grey_close_x.svg/1024px-Grey_close_x.svg.png" class="close-icon" id="close_msg" onclick="deleteMsg();">
			</div>
              
              
		</div> <!--main body end -->
	</body>
</html>
